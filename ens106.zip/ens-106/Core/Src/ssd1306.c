#include "ssd1306.h"

void SSD1306_Init(void) {
    // OLED 초기화 루틴 (생략 가능)
}
void SSD1306_UpdateScreen(void) {}
void SSD1306_Clear(void) {}
void SSD1306_GotoXY(uint16_t x, uint16_t y) {}
char SSD1306_Putc(char ch, FontDef Font, SSD1306_COLOR color) { return ch; }
char SSD1306_Puts(char* str, FontDef Font, SSD1306_COLOR color) { return *str; }
