#include "fonts.h"

const uint16_t font6x8 [] = {0x00}; // 실제 폰트 데이터는 프로젝트에 맞게 넣어야 함
const uint16_t font7x10 [] = {0x00};

FontDef Font_6x8 = {6, 8, font6x8};
FontDef Font_7x10 = {7, 10, font7x10};
