#ifndef __SSD1306_H__
#define __SSD1306_H__

#include "fonts.h"
#include "stm32f4xx_hal.h"

#define SSD1306_I2C_ADDR         0x78
#define SSD1306_WIDTH            128
#define SSD1306_HEIGHT           64

typedef enum {
    Black = 0x00,
    White = 0x01
} SSD1306_COLOR;

void SSD1306_Init(void);
void SSD1306_UpdateScreen(void);
void SSD1306_Clear(void);
void SSD1306_GotoXY(uint16_t x, uint16_t y);
char SSD1306_Putc(char ch, FontDef Font, SSD1306_COLOR color);
char SSD1306_Puts(char* str, FontDef Font, SSD1306_COLOR color);

#endif
