#ifndef FONTS_H_
#define FONTS_H_

#include "stm32f4xx_hal.h" // 사용 중인 MCU에 맞게 수정

typedef struct {
    const uint8_t FontWidth;
    const uint8_t FontHeight;
    const uint16_t *data;
} FontDef;

extern FontDef Font_6x8;
extern FontDef Font_7x10;

#endif
