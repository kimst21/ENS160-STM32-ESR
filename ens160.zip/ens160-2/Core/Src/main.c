/* USER CODE BEGIN Includes */
#include "main.h"
#include "i2c.h"
#include "usb_device.h"
#include "gpio.h"
#include "usbd_cdc_if.h"
#include "ssd1306.h"
#include "fonts.h"
#include <stdio.h>
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
#define ENS160_I2C_ADDR  (0x53 << 1)  // ENS160 8비트 주소: 0xA6

extern I2C_HandleTypeDef hi2c3;       // I2C3 핸들 (CubeMX 생성)

uint16_t eco2 = 0, tvoc = 0;               // 현재 측정값
uint16_t eco2_min = 0xFFFF, eco2_max = 0; // 최소/최대값 저장용
uint16_t tvoc_min = 0xFFFF, tvoc_max = 0;
char str[64];                             // CDC 및 OLED 문자열 버퍼
/* USER CODE END PV */

/* USER CODE BEGIN PFP */
uint8_t ENS160_Init(I2C_HandleTypeDef *hi2c);
uint8_t ENS160_ReadGas(I2C_HandleTypeDef *hi2c, uint16_t *eco2, uint16_t *tvoc);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* ENS160 센서 초기화 함수 */
uint8_t ENS160_Init(I2C_HandleTypeDef *hi2c)
{
    uint8_t mode = 0x02;  // Standard mode 설정
    if (HAL_I2C_Mem_Write(hi2c, ENS160_I2C_ADDR, 0x10, 1, &mode, 1, HAL_MAX_DELAY) != HAL_OK)
        return 0;

    uint8_t status = 0;
    uint32_t timeout = HAL_GetTick();

    do {
        if (HAL_I2C_Mem_Read(hi2c, ENS160_I2C_ADDR, 0x20, 1, &status, 1, HAL_MAX_DELAY) != HAL_OK)
            return 0;

        if ((HAL_GetTick() - timeout) > 5000)
            return 0;

        HAL_Delay(10);
    } while (!(status & 0x01));  // 데이터 준비 완료 상태 확인

    return 1;
}

/* ENS160 측정값 읽기 함수 */
uint8_t ENS160_ReadGas(I2C_HandleTypeDef *hi2c, uint16_t *eco2, uint16_t *tvoc)
{
    uint8_t buf[4];
    if (HAL_I2C_Mem_Read(hi2c, ENS160_I2C_ADDR, 0x22, 1, buf, 4, HAL_MAX_DELAY) != HAL_OK)
        return 0;

    *eco2 = (buf[1] << 8) | buf[0];
    *tvoc = (buf[3] << 8) | buf[2];
    return 1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_I2C3_Init();
  MX_USB_DEVICE_Init();

  /* USER CODE BEGIN 2 */
  SSD1306_Init();              // OLED 초기화
  SSD1306_Clear();             // 화면 초기화

  // CDC가 준비될 때까지 대기
  while (CDC_Transmit_FS((uint8_t*)"USB Ready\r\n", 11) != USBD_OK) {
      HAL_Delay(100);
  }

  ENS160_Init(&hi2c3);         // ENS160 센서 초기화
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if (ENS160_ReadGas(&hi2c3, &eco2, &tvoc)) {
        if (eco2 > eco2_max) eco2_max = eco2;
        if (eco2 < eco2_min) eco2_min = eco2;
        if (tvoc > tvoc_max) tvoc_max = tvoc;
        if (tvoc < tvoc_min) tvoc_min = tvoc;

        sprintf(str, "eCO2: %d ppm, TVOC: %d ppb\r\n", eco2, tvoc);
    } else {
        sprintf(str, "ENS160 Read Failed\r\n");
    }

    CDC_Transmit_FS((uint8_t*)str, strlen(str));  // USB 출력

    // OLED 출력 시작
    SSD1306_Fill(SSD1306_COLOR_BLACK); // 화면 전체를 검정색으로 덮음

    // eCO2 현재값 출력
    SSD1306_GotoXY(0, 0);
    sprintf(str, "eCO2: %d ppm", eco2);
    SSD1306_Puts(str, &Font_7x10, 1);

    // eCO2 최소/최대값 출력
    SSD1306_GotoXY(0, 12);
    sprintf(str, "L:%d  H:%d", eco2_min, eco2_max);
    SSD1306_Puts(str, &Font_7x10, 1);

    // TVOC 현재값 출력
    SSD1306_GotoXY(0, 28);
    sprintf(str, "TVOC: %d ppb", tvoc);
    SSD1306_Puts(str, &Font_7x10, 1);

    // TVOC 최소/최대값 출력
    SSD1306_GotoXY(0, 40);
    sprintf(str, "L:%d  H:%d", tvoc_min, tvoc_max);
    SSD1306_Puts(str, &Font_7x10, 1);

    SSD1306_UpdateScreen(); // 실제 OLED에 반영

    HAL_Delay(1000); // 1초 대기 후 반복
    /* USER CODE END WHILE */
  }
  /* USER CODE BEGIN 3 */
}
/* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
