/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"                 // I2C3 사용을 위한 HAL 드라이버
#include "usb_device.h"          // USB CDC 초기화용
#include "gpio.h"                // GPIO 초기화

/* USER CODE BEGIN Includes */
#include <stdio.h>               // sprintf() 함수 사용
#include "usbd_cdc_if.h"         // USB CDC 전송 함수 포함
#include "fonts.h"               // OLED에 사용할 폰트 정의
#include "ssd1306.h"             // OLED 제어 드라이버
#include "fonts.h"               // OLED에 사용할 폰트 정의
/* USER CODE END Includes */

/* USER CODE BEGIN PTD */
extern I2C_HandleTypeDef hi2c3;  // ENS160, OLED가 사용하는 I2C3
/* USER CODE END PTD */

/* USER CODE BEGIN PD */
// ENS160 센서 관련 레지스터 정의
#define ENS160_ADDR        (0x53 << 1)  // 7비트 주소를 STM32용 8비트 주소로 변환
#define ENS160_REG_OPMODE  0x10         // 작동 모드 설정 레지스터
#define ENS160_REG_ECO2    0x22         // eCO2 값 위치 (16bit)
#define ENS160_REG_TVOC    0x24         // TVOC 값 위치 (16bit)
/* USER CODE END PD */

/* USER CODE BEGIN PV */
// 최소, 최대, 평균 계산을 위한 변수
uint16_t min_eCO2 = 0xFFFF, max_eCO2 = 0;
uint32_t sum_eCO2 = 0;
uint16_t min_TVOC = 0xFFFF, max_TVOC = 0;
uint32_t sum_TVOC = 0;
uint32_t count = 0;   // 측정 횟수
/* USER CODE END PV */

/* USER CODE BEGIN 0 */
// ENS160을 NORMAL 모드로 설정하는 함수
void ENS160_Init(void) {
    uint8_t mode = 0x02; // NORMAL MODE
    HAL_I2C_Mem_Write(&hi2c3, ENS160_ADDR, ENS160_REG_OPMODE, 1, &mode, 1, HAL_MAX_DELAY);
}

// ENS160에서 16bit 값(eCO2, TVOC 등) 읽기
uint16_t ENS160_Read16(uint8_t reg) {
    uint8_t buf[2];
    HAL_I2C_Mem_Read(&hi2c3, ENS160_ADDR, reg, 1, buf, 2, HAL_MAX_DELAY);
    return (buf[1] << 8) | buf[0];  // 리틀 엔디안 변환
}
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();                // HAL 초기화
  SystemClock_Config();      // 클럭 설정
  MX_GPIO_Init();            // GPIO 초기화
  MX_I2C3_Init();            // I2C3 초기화 (ENS160 + OLED)
  MX_USB_DEVICE_Init();      // USB CDC 초기화
  SSD1306_Init();            // OLED 초기화
  ENS160_Init();             // ENS160 센서 초기화

  char line[64];             // 출력 문자열 버퍼

  while (1)
  {
    // 1. 센서 측정값 읽기
    uint16_t eco2 = ENS160_Read16(ENS160_REG_ECO2);
    uint16_t tvoc = ENS160_Read16(ENS160_REG_TVOC);

    // 2. 최소/최대 갱신
    if (eco2 < min_eCO2) min_eCO2 = eco2;
    if (eco2 > max_eCO2) max_eCO2 = eco2;
    if (tvoc < min_TVOC) min_TVOC = tvoc;
    if (tvoc > max_TVOC) max_TVOC = tvoc;

    // 3. 누적합 및 평균값 계산
    sum_eCO2 += eco2;
    sum_TVOC += tvoc;
    count++;

    uint16_t avg_eCO2 = sum_eCO2 / count;
    uint16_t avg_TVOC = sum_TVOC / count;

    // 4. OLED 화면 출력
    SSD1306_Clear();  // 화면 초기화

    sprintf(line, "eCO2: %4d ppm", eco2);
    SSD1306_GotoXY(0, 0); SSD1306_Puts(line, Font_7x10, 1);

    sprintf(line, "Min:%d Max:%d", min_eCO2, max_eCO2);
    SSD1306_GotoXY(0, 12); SSD1306_Puts(line, Font_6x8, 1);

    sprintf(line, "Avg:%d", avg_eCO2);
    SSD1306_GotoXY(0, 22); SSD1306_Puts(line, Font_6x8, 1);

    sprintf(line, "TVOC: %4d ppb", tvoc);
    SSD1306_GotoXY(0, 34); SSD1306_Puts(line, Font_7x10, 1);

    sprintf(line, "Min:%d Max:%d", min_TVOC, max_TVOC);
    SSD1306_GotoXY(0, 46); SSD1306_Puts(line, Font_6x8, 1);

    sprintf(line, "Avg:%d", avg_TVOC);
    SSD1306_GotoXY(0, 56); SSD1306_Puts(line, Font_6x8, 1);

    SSD1306_UpdateScreen(); // OLED 화면 갱신

    // 5. USB CDC로 측정값 출력
    sprintf(line, "eCO2:%d ppm (min:%d max:%d avg:%d)\r\n", eco2, min_eCO2, max_eCO2, avg_eCO2);
    CDC_Transmit_FS((uint8_t*)line, strlen(line));

    sprintf(line, "TVOC:%d ppb (min:%d max:%d avg:%d)\r\n", tvoc, min_TVOC, max_TVOC, avg_TVOC);
    CDC_Transmit_FS((uint8_t*)line, strlen(line));

    HAL_Delay(1000);  // 1초마다 갱신
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
