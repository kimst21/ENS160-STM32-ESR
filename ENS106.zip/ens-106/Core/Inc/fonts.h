#ifndef __FONTS_H__
#define __FONTS_H__

#include <stdint.h>

typedef struct {
    uint8_t width;
    uint8_t height;
    const uint8_t *data;
} FontDef;

extern FontDef Font_6x8;
extern FontDef Font_7x10;

#endif // __FONTS_H__
